
initFooterConfig(); 

initFooterConfig(); 